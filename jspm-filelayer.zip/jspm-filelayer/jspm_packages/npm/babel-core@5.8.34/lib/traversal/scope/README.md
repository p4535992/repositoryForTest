## Scope Traversal

This is the Scope Traversal directory.
