'use strict';

// set up before Leaflet files to test L#noConflict later
L = 'test';

//# sourceMappingURL=before-compiled.js.map