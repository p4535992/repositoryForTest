"use strict";

/*
 * CircleMarker canvas specific drawing parts.
 */

L.CircleMarker.include(!L.Path.CANVAS ? {} : {
	_updateStyle: function _updateStyle() {
		L.Path.prototype._updateStyle.call(this);
	}
});

//# sourceMappingURL=CircleMarker.Canvas-compiled.js.map