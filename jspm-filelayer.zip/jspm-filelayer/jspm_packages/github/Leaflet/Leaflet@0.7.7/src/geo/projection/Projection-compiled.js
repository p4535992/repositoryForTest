"use strict";

/*
 * L.Projection contains various geographical projections used by CRS classes.
 */

L.Projection = {};

//# sourceMappingURL=Projection-compiled.js.map