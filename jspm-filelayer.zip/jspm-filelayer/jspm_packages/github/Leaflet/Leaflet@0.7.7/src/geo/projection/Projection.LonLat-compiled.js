"use strict";

/*
 * Simple equirectangular (Plate Carree) projection, used by CRS like EPSG:4326 and Simple.
 */

L.Projection.LonLat = {
	project: function project(latlng) {
		return new L.Point(latlng.lng, latlng.lat);
	},

	unproject: function unproject(point) {
		return new L.LatLng(point.y, point.x);
	}
};

//# sourceMappingURL=Projection.LonLat-compiled.js.map