'use strict';

/*
 * L.Handler.DoubleClickZoom is used to handle double-click zoom on the map, enabled by default.
 */

L.Map.mergeOptions({
	doubleClickZoom: true
});

L.Map.DoubleClickZoom = L.Handler.extend({
	addHooks: function addHooks() {
		this._map.on('dblclick', this._onDoubleClick, this);
	},

	removeHooks: function removeHooks() {
		this._map.off('dblclick', this._onDoubleClick, this);
	},

	_onDoubleClick: function _onDoubleClick(e) {
		var map = this._map,
		    zoom = map.getZoom() + (e.originalEvent.shiftKey ? -1 : 1);

		if (map.options.doubleClickZoom === 'center') {
			map.setZoom(zoom);
		} else {
			map.setZoomAround(e.containerPoint, zoom);
		}
	}
});

L.Map.addInitHook('addHandler', 'doubleClickZoom', L.Map.DoubleClickZoom);

//# sourceMappingURL=Map.DoubleClickZoom-compiled.js.map