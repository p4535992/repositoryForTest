define(["github:Leaflet/Leaflet@0.7.7/dist/leaflet-src"], function(main) {
  return main;
});