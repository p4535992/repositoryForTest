"use strict";

define(["github:Leaflet/Leaflet@0.7.7/dist/leaflet-src"], function (main) {
  return main;
});

//# sourceMappingURL=Leaflet@0.7.7-compiled.js.map