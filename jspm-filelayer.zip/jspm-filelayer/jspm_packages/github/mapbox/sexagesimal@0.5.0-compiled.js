"use strict";

module.exports = require("github:mapbox/sexagesimal@0.5.0/index");

//# sourceMappingURL=sexagesimal@0.5.0-compiled.js.map