"use strict";

function _typeof(obj) { return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj; }

!(function (n, r) {
  "object" == (typeof exports === "undefined" ? "undefined" : _typeof(exports)) && "undefined" != typeof module ? r(exports) : "function" == typeof define && define.amd ? define("d3-dsv", ["exports"], r) : r(n.d3_dsv = {});
})(undefined, function (n) {
  "use strict";
  function r(n) {
    return new i(n);
  }function t(n) {
    return new Function("d", "return {" + n.map(function (n, r) {
      return JSON.stringify(n) + ": d[" + r + "]";
    }).join(",") + "}");
  }function e(n, r) {
    var e = t(n);return function (n, t) {
      return r(e(n), t);
    };
  }function o(n) {
    var r = Object.create(null),
        t = [];return n.forEach(function (n) {
      for (var e in n) {
        e in r || t.push(r[e] = e);
      }
    }), t;
  }function i(n) {
    function r(r) {
      return r.map(i).join(n);
    }function i(n) {
      return u.test(n) ? '"' + n.replace(/\"/g, '""') + '"' : n;
    }var u = new RegExp('["' + n + "\n]"),
        c = n.charCodeAt(0);this.parse = function (n, r) {
      var o,
          i,
          u = this.parseRows(n, function (n, u) {
        return o ? o(n, u - 1) : (i = n, void (o = r ? e(n, r) : t(n)));
      });return u.columns = i, u;
    }, this.parseRows = function (n, r) {
      function t() {
        if (s >= a) return u;if (o) return o = !1, i;var r = s;if (34 === n.charCodeAt(r)) {
          for (var t = r; t++ < a;) {
            if (34 === n.charCodeAt(t)) {
              if (34 !== n.charCodeAt(t + 1)) break;++t;
            }
          }s = t + 2;var e = n.charCodeAt(t + 1);return 13 === e ? (o = !0, 10 === n.charCodeAt(t + 2) && ++s) : 10 === e && (o = !0), n.slice(r + 1, t).replace(/""/g, '"');
        }for (; a > s;) {
          var e = n.charCodeAt(s++),
              f = 1;if (10 === e) o = !0;else if (13 === e) o = !0, 10 === n.charCodeAt(s) && (++s, ++f);else if (e !== c) continue;return n.slice(r, s - f);
        }return n.slice(r);
      }for (var e, o, i = {}, u = {}, f = [], a = n.length, s = 0, p = 0; (e = t()) !== u;) {
        for (var d = []; e !== i && e !== u;) {
          d.push(e), e = t();
        }r && null == (d = r(d, p++)) || f.push(d);
      }return f;
    }, this.format = function (r, t) {
      return arguments.length < 2 && (t = o(r)), [t.map(i).join(n)].concat(r.map(function (r) {
        return t.map(function (n) {
          return i(r[n]);
        }).join(n);
      })).join("\n");
    }, this.formatRows = function (n) {
      return n.map(r).join("\n");
    };
  }r.prototype = i.prototype;var u = r(","),
      c = r("	"),
      f = "0.1.11";n.version = f, n.dsv = r, n.csv = u, n.tsv = c;
});

//# sourceMappingURL=d3-dsv.min-compiled.js.map