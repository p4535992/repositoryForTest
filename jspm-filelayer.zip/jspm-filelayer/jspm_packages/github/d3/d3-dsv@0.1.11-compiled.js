"use strict";

define(["github:d3/d3-dsv@0.1.11/d3-dsv"], function (main) {
  return main;
});

//# sourceMappingURL=d3-dsv@0.1.11-compiled.js.map